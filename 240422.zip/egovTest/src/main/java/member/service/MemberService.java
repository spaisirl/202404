package member.service;

import java.util.List;

public interface MemberService {
	/*회원등록처리*/
	public String insertMember(MemberVO vo) throws Exception;
	
	// 아이디 중복 체크
	public int idChk(String userid);
	
	// 회원저장
	public String memberWriteSave(MemberVO vo) throws Exception;
	
	// 로그인
	public int loginProc(MemberVO vo);
	
	// 회원 목록
	public List<MemberVO> memberList() throws Exception;

}
