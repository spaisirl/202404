package member.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import member.service.MemberService;
import member.service.MemberVO;

@Controller
public class MemberController {
	@Resource(name="memberService")
	public MemberService memberService;
	/*회원등록 페이지 호출*/
	@RequestMapping("memberWrite.do")
	public String memberWrite() {
		return "member/memberWrite";
	}
	
	@RequestMapping("memberWriteSave.do") 
	@ResponseBody
	public String insertMember(MemberVO vo) throws Exception {
		String message = "";
		System.out.println("id : " + vo.getUserid());
		
		String result = memberService.insertMember(vo);
		if (result == null) {
			message = "ok";
		}
		System.out.println("message: " + message);
		return message;		
	}
	
	@RequestMapping("idChk.do")
	@ResponseBody
	public String idChk(String userid) throws Exception {
		
		String message = "";
		System.out.println("userid : " + userid);
		
		// 중복 체크를 위한 Service 호출
	    int result = memberService.idChk(userid);
	    
	    if (result == 0) {
			message = "ok";
		}	    
	    return message;
	}
	
	/*
	 * 2024-04-22
	 * 아래 최초 작성
	 * 2024~ 
	 * */
	
	@RequestMapping("logout.do")
	public String logout(HttpSession session) {
		session.removeAttribute("sessionId");
		return "member/main";
	}
	
	@RequestMapping("main.do")
	public String main() {
		return "member/main";
	}
	
	@RequestMapping("login.do")
	public String login() {
		return "member/login";
	}
	
	@ResponseBody
	@RequestMapping("loginProc.do")
	public String loginProc(MemberVO vo, HttpSession session) throws Exception {
		
		String message = "";
		int cnt = memberService.idChk(vo.getUserid());
		System.out.println("cnt : " +cnt);
		
		if(cnt == 0) {
			message = "x";
		} else {
			int cnt2 = memberService.loginProc(vo);
			if (cnt2 == 0 ) {
				
				message = "fail";
			} else {
				session.setAttribute("sessionId", vo.getUserid());
				message = "ok";
			}
			
			
		}

		return message;
	}
	
	@RequestMapping("memberList.do")
	public String memberList(Model model) throws Exception {
		
		List<MemberVO> memberList = memberService.memberList();
		System.out.println("List" + memberList);
		
		model.addAttribute("memberList", memberList);

		return "member/memberList";
	}
	
	
}
