package member.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import member.service.MemberVO;

// 데이터베이스에 접근하는 메서드를 가지고 있는 클래스에 쓰인다.
@Repository("memberDAO")
public class MemberDAO extends EgovAbstractDAO {
	
	public String insertMember(MemberVO vo) {
		return (String) insert("memberDAO.insertMember", vo);
	}
	
	// 아이디 중복체크
	public int idChk(String userid){
		return (int) select("memberDAO.idChk", userid);
	}
	
	// 회원 저장
	public String memberWriteSave(MemberVO vo){
		return (String) insert("memberDAO.memberWriteSave", vo);
	}
	
	// 로그인
	public int loginProc(MemberVO vo){
		return (int) select("memberDAO.loginProc", vo);
	}
	
	// 회원 목록
	@SuppressWarnings("unchecked")
	public List<MemberVO> memberList() {
		
		return (List<MemberVO>) list("memberDAO.memberList");
	}
	
}
